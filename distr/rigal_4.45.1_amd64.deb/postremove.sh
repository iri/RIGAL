#!/bin/bash
rmdir --ignore-fail-on-non-empty /usr/include/rigal/
