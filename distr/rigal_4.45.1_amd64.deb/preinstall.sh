#!/bin/bash
mkdir -p /usr/include/rigal/
